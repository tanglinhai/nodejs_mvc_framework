jQuery(window).load(function(){
    jQuery('#tzloadding').remove();

});
